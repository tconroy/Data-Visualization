Tom Conroy
RIT 2014
Spring Semester

I decided to make an animated clock with tick-tock sound effects while experimenting with Canvas! :)
#ICE_05
## Tom Conroy

I will be using the RottenTomatoes.com movie API as my data source.
The specific search query used is "Star Wars". URI outlined below.

- API Home URL:       http://developer.rottentomatoes.com/page
- API REST tester:    http://developer.rottentomatoes.com/io-docs
- Data Source URL:    http://api.rottentomatoes.com/api/public/v1.0/movies.json?q=Star+Wars&page_limit=10&page=1&apikey=qnj3vbtcpy8dvxy2bs4m66x6
- Data Source Format: JSON/P